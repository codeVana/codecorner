package com.intel.circularprimes;

import com.intel.circularprimes.algorithms.rotationalprimes.*;
import com.intel.circularprimes.service.*;
import org.apache.commons.lang3.time.*;

public class Application {
	
	private final static int MIN_RANGE = 1;
	private final static int MAX_RANGE = 1000000;
	
	public static void main(String[] args) {
		executeAndCompare();
	}
	
	@SuppressWarnings("unused")
	private static void executeSingleThreaded() {
		StopWatch timer = new StopWatch();
		ApplicationService service = new ApplicationService(new RotationalPrimesComputation());
		
		timer.start();
		int count = service.calculate(MIN_RANGE, MAX_RANGE);
		timer.stop();

		System.out.println(String.format("Total time = %s ms. Answer = %s", timer.getTime(), count));
	}
	
	@SuppressWarnings("unused")
	private static void executeMultiThreaded() {
		StopWatch timer = new StopWatch();
		ApplicationService service = new ApplicationService(new MultiThreadedRotationalPrimesComputation());
		
		timer.start();
		int count = service.calculate(MIN_RANGE, MAX_RANGE);
		timer.stop();

		System.out.println(String.format("Total time = %s ms. Answer = %s", timer.getTime(), count));
	}

	private static void executeAndCompare() {
		executeAndCompare(5);
	}
	
	private static void executeAndCompare(int iterations) {
		
		StopWatch timer = new StopWatch();
		
		int count = 0;
		long totalTime = 0;

		ApplicationService service = new ApplicationService(new RotationalPrimesComputation()); //new MultiThreadedRotationalPrimesComputation() // new MultiThreadedRotationalPrimesComputation()
		
		System.out.println(String.format("Running %s single-threaded rotational prime computations for range %s to %s", iterations, MIN_RANGE, MAX_RANGE));
		System.out.println("---");
		
		for(int i = 0; i < iterations; i++) {
			
			timer.reset();
			timer.start();
			count = service.calculate(MIN_RANGE, MAX_RANGE);
			timer.stop();
			totalTime = totalTime + timer.getTime();
			
			System.out.println(String.format("Run #%s, %s ms.", i + 1, timer.getTime()));
		}
		
		System.out.println("");
		System.out.println(String.format("Total time = %s ms. Average = %s ms. Answer = %s", totalTime, Math.ceil(totalTime / iterations), count));
		System.out.println("");
		System.out.println("===");
		System.out.println("");
		
		service = new ApplicationService(new MultiThreadedRotationalPrimesComputation());
		
		System.out.println(String.format("Running %s multi-threaded rotational prime computations for range %s to %s", iterations, MIN_RANGE, MAX_RANGE));
		System.out.println("---");
		
		totalTime = 0;
		
		for(int i = 0; i < iterations; i++) {
			
			timer.reset();
			timer.start();
			count = service.calculate(MIN_RANGE, MAX_RANGE);
			timer.stop();
			totalTime = totalTime + timer.getTime();
			
			System.out.println(String.format("Run #%s, %s ms.", i + 1, timer.getTime()));
		}
		
		System.out.println("");
		System.out.println(String.format("Total time = %s ms. Average = %s ms. Answer = %s", totalTime, Math.ceil(totalTime / iterations), count));
	}
}
