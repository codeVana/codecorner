package com.intel.circularprimes.utilities;

public class PrimeNumberHelper {
	
	public static boolean isPrime(int number) {
		
		if(number <= 1) { // Negative numbers, zero, and one are not considered prime numbers
			return false;
		}

		if(number % 2 == 0) {
			if(number == 2) {
				return true;
			}
			return false;
		}

		int squareRoot = (int) Math.sqrt(number); // No need to check beyond the number's square root
		
		for (int i = 3; i <= squareRoot; i += 2) { // No need to check even numbers
			if ((number % i) == 0) {
				return false;
			}
		}
		return true;
	}
}
