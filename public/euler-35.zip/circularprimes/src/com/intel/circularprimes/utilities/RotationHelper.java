package com.intel.circularprimes.utilities;

import java.util.*;

public class RotationHelper {
	
	public static List<Integer> getRotationsForNumber(Integer number) {
		
		List<Integer> rotations = new ArrayList<Integer>();

		if(number.intValue() > 0) {
			
			String data = number.toString();			
			StringBuilder builder = new StringBuilder();
			Integer rotation;
			
			for(int i = 1; i < data.length(); i++) {
				
				builder.setLength(0);				
				builder.append(data.substring(i));
				builder.append(data.substring(0, i));
				
				try {
					rotation = Integer.valueOf(builder.toString());
					if(rotation.intValue() > 0 && !rotations.contains(rotation)) {
						rotations.add(rotation);
					}
				}
				catch(NumberFormatException e) {
					e.printStackTrace();
				}
			}
		}
		return rotations;
	}

}
