package com.intel.circularprimes.service;

import com.intel.circularprimes.algorithms.IComputation;

public class ApplicationService {
	
	private IComputation algorithm;
	
	public ApplicationService(IComputation algorithm) {
		this.algorithm = algorithm;
	}
	
	public Integer calculate(int minRange, int maxRange) {		
		int result = 0;
		try {
			result = algorithm.calculate(minRange, maxRange);
		}
		catch (Exception e) {
			System.out.println(String.format("Service invocation failed. Reason: \n%s\n\n", e.getMessage()));
		}
		return result;
	}
}
