package com.intel.circularprimes.algorithms.rotationalprimepalindrome;

import com.intel.circularprimes.algorithms.*;
import com.intel.circularprimes.data.entities.ProjectEulerNumber;

public class RotationalPrimePalindromeComputation implements IComputation {

	public int calculate(int minRange, int maxRange) throws Exception {
		if(minRange < 0 || minRange >= maxRange) {
			throw new Exception("An invalid range was specified. Please check to make sure the start number is greater than 0 and less than the end number.");
		}
		int count = 0;
		for(int i = minRange; i <= maxRange; i++) {
			ProjectEulerNumber number = new ProjectEulerNumber(i);
			if(number.isCircularPrimePalindrome()) {
				count++;
				System.out.println(String.format("Rotational prime palindrome #%d: %s", (count + 1), number.getData()));
			}
		}
		return count;
	}
}
