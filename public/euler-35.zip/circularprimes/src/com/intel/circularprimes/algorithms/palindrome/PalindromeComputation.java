package com.intel.circularprimes.algorithms.palindrome;

import com.intel.circularprimes.algorithms.IComputation;
import com.intel.circularprimes.data.entities.ProjectEulerNumber;

public class PalindromeComputation implements IComputation {

	public int calculate(int minRange, int maxRange) throws Exception {
		if(minRange < 0 || minRange >= maxRange) {
			throw new Exception("An invalid range was specified. Please check to make sure the start number is greater than 0 and less than the end number.");
		}
		int palindromeCount = 0;
		for(int i = minRange; i <= maxRange; i++) {
			ProjectEulerNumber number = new ProjectEulerNumber(i);			
			if(number.isPalindrome()) {
				System.out.println(String.format("Palindrome #%d: %s", (palindromeCount + 1), number.getData()));
				palindromeCount++;
			}
		}
		return palindromeCount;
	}

}
