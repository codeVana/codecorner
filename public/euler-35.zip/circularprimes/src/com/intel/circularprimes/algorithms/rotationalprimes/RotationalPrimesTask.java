package com.intel.circularprimes.algorithms.rotationalprimes;

import java.util.concurrent.*;
import com.intel.circularprimes.data.entities.*;

public class RotationalPrimesTask extends RecursiveTask<Integer> {

	private static final long serialVersionUID = 6396772570241742102L;
	protected static int threshold = 10000;
	private int start;
	private int end;
	
	public RotationalPrimesTask(int start, int end) {
		this.start = start;
		this.end = end;
	}
	
	@Override
	protected Integer compute() {
		
		int remaining = end - start;
		
		if(remaining <= threshold) {
			return computeDirectly();
		}
		
		int mid = (int) Math.floor(remaining / 2);
		
		RotationalPrimesTask worker1 = new RotationalPrimesTask(start, start + mid);
		RotationalPrimesTask worker2 = new RotationalPrimesTask(start + mid + 1, end);
		
		worker1.fork();
		
		Integer x = worker2.compute();
		Integer y = worker1.join();
		
		return new Integer(x.intValue() + y.intValue());
	}
	
	private Integer computeDirectly() {
		int count = 0;
		for (int i = start; i < end; i++) {
			ProjectEulerNumber number = new ProjectEulerNumber(i);
			if (number.isCircularPrime()) {
				count++;
			}
		}
		return new Integer(count);
	}

}
