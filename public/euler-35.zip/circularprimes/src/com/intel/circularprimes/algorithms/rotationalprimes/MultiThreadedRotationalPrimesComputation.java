package com.intel.circularprimes.algorithms.rotationalprimes;

import java.util.concurrent.*;
import com.intel.circularprimes.algorithms.*;

public class MultiThreadedRotationalPrimesComputation implements IComputation {

	public int calculate(int minRange, int maxRange) throws Exception {
		if(minRange < 0 || minRange >= maxRange) {
			throw new Exception("An invalid range was specified. Please check to make sure the start number is greater than 0 and less than the end number.");
		}
		
		int count = 0;
		int processors = Runtime.getRuntime().availableProcessors();
		ForkJoinPool pool = new ForkJoinPool(processors);
		RotationalPrimesTask task = new RotationalPrimesTask(minRange, maxRange);
		
		try {
			Integer result = pool.invoke(task);
			count = result.intValue();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return count;
	}

}
