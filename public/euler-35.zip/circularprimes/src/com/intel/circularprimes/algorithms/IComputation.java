package com.intel.circularprimes.algorithms;

public interface IComputation {
	public abstract int calculate(int minRange, int maxRange) throws Exception;
}
