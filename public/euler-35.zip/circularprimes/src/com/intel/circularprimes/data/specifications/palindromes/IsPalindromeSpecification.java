package com.intel.circularprimes.data.specifications.palindromes;

import com.intel.circularprimes.data.entities.*;
import com.intel.circularprimes.data.specifications.CompositeSpecification;

public class IsPalindromeSpecification extends CompositeSpecification<ProjectEulerNumber> {

	@Override
	public boolean isSatisfiedBy(ProjectEulerNumber candidate) {
		
		int data = candidate.getData();
		
		if (data < 0) {
			return false;
		}
 
		int precision = 1;
		
		while (data / precision >= 10) {
			precision *= 10;
		}
 
		while (data != 0) {
			int left = data / precision;
			int right = data % 10;
			if (left != right) {
				return false;
			}
			data = (data % precision) / 10;
			precision /= 100;
		}
		return true;
	}
}
