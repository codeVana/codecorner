package com.intel.circularprimes.data.specifications;

public class NotSpecification<T> extends CompositeSpecification<T> {
	
	private ISpecification<T> specification;
	
	public NotSpecification(ISpecification<T> specification) {
		this.specification = specification;
	}

	@Override
	public boolean isSatisfiedBy(T candidate) {
		return !specification.isSatisfiedBy(candidate);
	}
}
