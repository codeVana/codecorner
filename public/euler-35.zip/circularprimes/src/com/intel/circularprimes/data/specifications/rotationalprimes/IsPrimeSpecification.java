package com.intel.circularprimes.data.specifications.rotationalprimes;

import com.intel.circularprimes.data.entities.*;
import com.intel.circularprimes.data.specifications.CompositeSpecification;
import com.intel.circularprimes.utilities.*;

public class IsPrimeSpecification extends CompositeSpecification<ProjectEulerNumber> {
	@Override
	public boolean isSatisfiedBy(ProjectEulerNumber candidate){
		return PrimeNumberHelper.isPrime(candidate.getData());
	}
}
