package com.intel.circularprimes.data.specifications;

public interface ISpecification<T> {
	abstract boolean isSatisfiedBy(T candidate);
	abstract ISpecification<T> And(ISpecification<T> other);
}
