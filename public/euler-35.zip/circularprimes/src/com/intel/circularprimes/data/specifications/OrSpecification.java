package com.intel.circularprimes.data.specifications;

public class OrSpecification<T> extends CompositeSpecification<T> {
	
	private ISpecification<T> leftSpecification;
	private ISpecification<T> rightSpecification;
	
	public OrSpecification(ISpecification<T> leftSpecification, ISpecification<T> rightSpecification) {
		this.leftSpecification = leftSpecification;
		this.rightSpecification = rightSpecification;
	}
	
	@Override
	public boolean isSatisfiedBy(T candidate) {
		return leftSpecification.isSatisfiedBy(candidate) || rightSpecification.isSatisfiedBy(candidate);
	}
}
