package com.intel.circularprimes.data.specifications;

public class AndSpecification<T> extends CompositeSpecification<T> {
	
	private ISpecification<T> leftSpecification;
	private ISpecification<T> rightSpecification;
	
	public AndSpecification(ISpecification<T> leftSpecification, ISpecification<T> rightSpecification) {
		this.leftSpecification = leftSpecification;
		this.rightSpecification = rightSpecification;
	}

	@Override
	public boolean isSatisfiedBy(T candidate) {
		return leftSpecification.isSatisfiedBy(candidate) && rightSpecification.isSatisfiedBy(candidate);
	}
}
