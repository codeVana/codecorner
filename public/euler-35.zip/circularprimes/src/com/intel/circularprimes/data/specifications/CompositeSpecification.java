package com.intel.circularprimes.data.specifications;

public abstract class CompositeSpecification<T> implements ISpecification<T> {
	
	public abstract boolean isSatisfiedBy(T candidate);
	
	public ISpecification<T> And(ISpecification<T> specification) {
		return new AndSpecification<T>(this, specification);
	}
}
