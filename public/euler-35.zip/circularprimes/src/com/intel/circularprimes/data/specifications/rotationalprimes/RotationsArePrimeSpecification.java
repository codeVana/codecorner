package com.intel.circularprimes.data.specifications.rotationalprimes;

import com.intel.circularprimes.data.entities.*;
import com.intel.circularprimes.data.specifications.CompositeSpecification;
import com.intel.circularprimes.utilities.*;
import java.util.*;

public class RotationsArePrimeSpecification extends CompositeSpecification<ProjectEulerNumber> {
	@Override
	public boolean isSatisfiedBy(ProjectEulerNumber candidate) {		
		List<Integer> rotations = RotationHelper.getRotationsForNumber(candidate.getData());
		for(Integer rotation : rotations) {
			if(!PrimeNumberHelper.isPrime(rotation)) {
				return false;
			}
		}
		return true;
	}
}
