package com.intel.circularprimes.data.entities;

import com.intel.circularprimes.data.specifications.*;
import com.intel.circularprimes.data.specifications.rotationalprimes.*;
import com.intel.circularprimes.data.specifications.palindromes.*;

public class ProjectEulerNumber {
	
	private ISpecification<ProjectEulerNumber> primeSpecification;
	private ISpecification<ProjectEulerNumber> primeRotationsSpecification;
	private ISpecification<ProjectEulerNumber> palindromeSpecification;
	
	private int data;
	
	public ProjectEulerNumber(int data) {
		primeSpecification = new IsPrimeSpecification();
		primeRotationsSpecification = new RotationsArePrimeSpecification();
		palindromeSpecification = new IsPalindromeSpecification();
		this.data = data;
	}
	
	public int getData() {
		return this.data;
	}
	
	public boolean isCircularPrime() {
		return primeSpecification.And(primeRotationsSpecification).isSatisfiedBy(this);
	}
	
	public boolean isPalindrome() {
		return palindromeSpecification.isSatisfiedBy(this);
	}
	
	public boolean isCircularPrimePalindrome() {
		return primeSpecification.And(primeRotationsSpecification).And(palindromeSpecification).isSatisfiedBy(this);
	}
}
